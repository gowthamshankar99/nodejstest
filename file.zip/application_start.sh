cd /home/ec2-user/ && npm install
sudo systemctl daemon-reload
sudo systemctl start app
sudo systemctl restart app