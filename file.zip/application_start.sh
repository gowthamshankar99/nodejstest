npm install
sudo systemctl daemon-reload
sudo systemctl start app